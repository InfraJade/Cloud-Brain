"""
Bedrock Agent action group: read-only AWS infra + cost tools.
Handler: agent_tools_lambda.lambda_handler   Timeout: 120s   Memory: 512 MB
"""
import json
import os
from datetime import datetime, timedelta, timezone

import boto3

DEFAULT_REGION = os.environ.get("DEFAULT_REGION", "us-east-1")
MAX_RESPONSE_CHARS = 20000  # Bedrock Agents cap Lambda responses at ~25 KB
IDLE_CPU_THRESHOLD = float(os.environ.get("IDLE_CPU_THRESHOLD", "5"))


def _params(event):
    return {p["name"]: p["value"] for p in event.get("parameters", [])}


def _tag(tags, key="Name"):
    return next((t["Value"] for t in (tags or []) if t["Key"] == key), None)


# ---------------------------------------------------------------- tools

def list_running_resources(region):
    ec2 = boto3.client("ec2", region_name=region)
    rds = boto3.client("rds", region_name=region)

    instances = []
    for page in ec2.get_paginator("describe_instances").paginate(
        Filters=[{"Name": "instance-state-name", "Values": ["running"]}]
    ):
        for r in page["Reservations"]:
            for i in r["Instances"]:
                instances.append({
                    "id": i["InstanceId"],
                    "name": _tag(i.get("Tags")),
                    "type": i["InstanceType"],
                    "launched": i["LaunchTime"].isoformat(),
                    "lifecycle": i.get("InstanceLifecycle", "on-demand"),
                })

    dbs = [{
        "id": d["DBInstanceIdentifier"],
        "class": d["DBInstanceClass"],
        "engine": d["Engine"],
        "multi_az": d["MultiAZ"],
        "status": d["DBInstanceStatus"],
    } for d in rds.describe_db_instances()["DBInstances"]]

    return {"region": region, "ec2_running": instances, "rds_instances": dbs,
            "counts": {"ec2": len(instances), "rds": len(dbs)}}


def get_cost_breakdown(days, group_by):
    # Cost Explorer is global (us-east-1). Each call costs $0.01.
    ce = boto3.client("ce", region_name="us-east-1")
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=days)
    dim = {"service": "SERVICE", "region": "REGION",
           "usage_type": "USAGE_TYPE", "account": "LINKED_ACCOUNT"}.get(group_by, "SERVICE")

    resp = ce.get_cost_and_usage(
        TimePeriod={"Start": start.isoformat(), "End": end.isoformat()},
        Granularity="MONTHLY",
        Metrics=["UnblendedCost"],
        GroupBy=[{"Type": "DIMENSION", "Key": dim}],
    )
    totals = {}
    for period in resp["ResultsByTime"]:
        for g in period["Groups"]:
            k = g["Keys"][0]
            totals[k] = totals.get(k, 0) + float(g["Metrics"]["UnblendedCost"]["Amount"])

    top = sorted(totals.items(), key=lambda x: x[1], reverse=True)[:15]
    return {"period": f"{start} to {end}", "grouped_by": dim,
            "total_usd": round(sum(totals.values()), 2),
            "top": [{"key": k, "usd": round(v, 2)} for k, v in top]}


def find_idle_resources(region):
    ec2 = boto3.client("ec2", region_name=region)
    cw = boto3.client("cloudwatch", region_name=region)
    findings = {}

    vols = ec2.describe_volumes(Filters=[{"Name": "status", "Values": ["available"]}])["Volumes"]
    findings["unattached_ebs_volumes"] = [
        {"id": v["VolumeId"], "size_gb": v["Size"], "type": v["VolumeType"]} for v in vols]

    eips = ec2.describe_addresses()["Addresses"]
    findings["unassociated_elastic_ips"] = [
        a["PublicIp"] for a in eips if "AssociationId" not in a]

    stopped = ec2.describe_instances(
        Filters=[{"Name": "instance-state-name", "Values": ["stopped"]}])
    findings["stopped_instances_still_paying_for_ebs"] = [
        {"id": i["InstanceId"], "name": _tag(i.get("Tags")), "type": i["InstanceType"]}
        for r in stopped["Reservations"] for i in r["Instances"]]

    # Low-CPU running instances (14-day average)
    low_cpu = []
    end = datetime.now(timezone.utc)
    running = ec2.describe_instances(
        Filters=[{"Name": "instance-state-name", "Values": ["running"]}])
    for r in running["Reservations"]:
        for i in r["Instances"]:
            stats = cw.get_metric_statistics(
                Namespace="AWS/EC2", MetricName="CPUUtilization",
                Dimensions=[{"Name": "InstanceId", "Value": i["InstanceId"]}],
                StartTime=end - timedelta(days=14), EndTime=end,
                Period=86400, Statistics=["Average", "Maximum"])
            points = stats["Datapoints"]
            if not points:
                continue
            avg = sum(p["Average"] for p in points) / len(points)
            peak = max(p["Maximum"] for p in points)
            if avg < IDLE_CPU_THRESHOLD:
                low_cpu.append({"id": i["InstanceId"], "name": _tag(i.get("Tags")),
                                "type": i["InstanceType"],
                                "avg_cpu_14d": round(avg, 2), "max_cpu_14d": round(peak, 2)})
    findings["low_cpu_instances"] = low_cpu
    return {"region": region, "idle_cpu_threshold_pct": IDLE_CPU_THRESHOLD, **findings}


def get_rightsizing_recommendations(region):
    co = boto3.client("compute-optimizer", region_name=region)
    try:
        recs = co.get_ec2_instance_recommendations()["instanceRecommendations"]
    except co.exceptions.OptInRequiredException:
        return {"error": "Compute Optimizer is not enabled for this account. "
                         "Enable it in the console (free) and wait ~12h for data."}

    out = []
    for r in recs:
        if r["finding"] == "OPTIMIZED":
            continue
        best = (r.get("recommendationOptions") or [{}])[0]
        savings = best.get("savingsOpportunity", {}).get("estimatedMonthlySavings", {})
        out.append({
            "instance": r["instanceArn"].split("/")[-1],
            "name": r.get("instanceName"),
            "finding": r["finding"],
            "current_type": r["currentInstanceType"],
            "recommended_type": best.get("instanceType"),
            "est_monthly_savings_usd": savings.get("value"),
            "performance_risk": best.get("performanceRisk"),
        })
    out.sort(key=lambda x: x["est_monthly_savings_usd"] or 0, reverse=True)
    return {"region": region, "recommendations": out[:25]}


# ---------------------------------------------------------------- router

def lambda_handler(event, context):
    fn = event.get("function")
    p = _params(event)
    region = p.get("region") or DEFAULT_REGION

    try:
        if fn == "list_running_resources":
            body = list_running_resources(region)
        elif fn == "get_cost_breakdown":
            body = get_cost_breakdown(int(p.get("days", 30)), p.get("group_by", "service"))
        elif fn == "find_idle_resources":
            body = find_idle_resources(region)
        elif fn == "get_rightsizing_recommendations":
            body = get_rightsizing_recommendations(region)
        else:
            body = {"error": f"Unknown function {fn}"}
    except Exception as e:  # return errors to the agent so it can explain them
        body = {"error": f"{type(e).__name__}: {e}"}

    text = json.dumps(body, default=str)
    if len(text) > MAX_RESPONSE_CHARS:
        text = text[:MAX_RESPONSE_CHARS] + '..."TRUNCATED"'

    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": event.get("actionGroup"),
            "function": fn,
            "functionResponse": {"responseBody": {"TEXT": {"body": text}}},
        },
        "sessionAttributes": event.get("sessionAttributes", {}),
        "promptSessionAttributes": event.get("promptSessionAttributes", {}),
    }
