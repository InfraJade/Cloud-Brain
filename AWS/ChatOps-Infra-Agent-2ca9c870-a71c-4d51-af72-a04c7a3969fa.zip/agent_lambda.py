"""
Interactive AWS resource-management agent (Bedrock Converse API + your existing Step Function).

Flow:  agent PROPOSES a change -> UI shows Confirm/Cancel -> THIS CODE (never the model)
       starts the Step Function -> UI polls status.

Deploy with agent_tools_lambda.py in the same package.
Handler: agent_lambda.lambda_handler   Timeout: 30s   Memory: 512 MB

Env:
  MODEL_ID           global.anthropic.claude-sonnet-5 (or a Nova 2 Lite profile ID)
  SESSION_TABLE      DynamoDB table, key "session_id" (S), TTL attribute "expires_at"
  STATE_MACHINE_ARN  your ChatOps provisioning state machine (Standard workflow)
  RESOURCES_TABLE    aws-ops-resources (queried via request_id-index)
  ADMIN_GROUP        optional; if set, only users in this Cognito group can delete
  DEFAULT_REGION     us-east-1

POST /agent request bodies (one route, three shapes):
  Chat:     {"session_id": "...", "message": "create an s3 bucket for logs"}
  Decision: {"session_id": "...", "action_id": "...", "decision": "confirm" | "cancel"}
  Status:   {"session_id": "...", "status_request_id": "..."}

Response:
  {"reply": "...", "session_id": "...",
   "actions":  [{"action_id", "kind", "summary", "params", "expires_in"}],   # show Confirm/Cancel
   "tracking": {"request_id", "state": "in_progress|done|failed", ...}}      # poll while in_progress
"""
import base64
import json
import os
import time
import uuid

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

from agent_tools_lambda import (
    find_idle_resources,
    get_cost_breakdown,
    get_rightsizing_recommendations,
    list_running_resources,
)

MODEL_ID = os.environ.get("MODEL_ID", "global.anthropic.claude-sonnet-5")
DEFAULT_REGION = os.environ.get("DEFAULT_REGION", "us-east-1")
SESSION_TABLE = os.environ["SESSION_TABLE"]
STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]
RESOURCES_TABLE = os.environ.get("RESOURCES_TABLE", "aws-ops-resources")
ADMIN_GROUP = os.environ.get("ADMIN_GROUP", "")

MAX_TOOL_ROUNDS = 8
HISTORY_TURNS = 10
SESSION_TTL_SECONDS = 86400
ACTION_TTL_SECONDS = 600          # pending actions expire after 10 minutes
MAX_TOOL_RESULT_CHARS = 20000
MIN_TIME_LEFT_MS = 8000

bedrock = boto3.client("bedrock-runtime")
sfn = boto3.client("stepfunctions")
ddb = boto3.resource("dynamodb")
sessions = ddb.Table(SESSION_TABLE)
resources = ddb.Table(RESOURCES_TABLE)

SYSTEM_PROMPT = """You are an AWS infrastructure, FinOps and resource-management assistant
inside our team's chat app.

READ: answer questions about running resources, costs and architecture using ONLY data
from your tools; never invent resource IDs, prices or numbers. For cost-saving questions
call get_cost_breakdown, find_idle_resources and get_rightsizing_recommendations first,
then give a prioritized list (resource, issue, action, estimated monthly saving, risk).

CHANGE: you can REQUEST provisioning (EC2, S3) and deletions.
- Before request_provision, make sure you have every required field. If something is
  missing, ask ONE short question at a time and suggest a sensible default
  (e.g. "t3.micro in dev?"). Never guess the environment.
- Before request_delete, confirm the ticket/resource with the user.
- These tools do NOT change anything. They create a pending request that the user must
  approve with the Confirm button shown in the chat. After calling one, summarize exactly
  what will happen in 1-3 lines and tell the user to press Confirm or Cancel.
- Never say a change is done unless check_request_status shows it finished.

Keep answers short and formatted for a chat window."""

_REGION = {"region": {"type": "string", "description": "AWS region, default us-east-1."}}

TOOL_SPECS = [
    # ---- read tools
    {"toolSpec": {"name": "list_running_resources",
                  "description": "List running EC2 instances and RDS databases in a region.",
                  "inputSchema": {"json": {"type": "object", "properties": _REGION}}}},
    {"toolSpec": {"name": "get_cost_breakdown",
                  "description": "AWS spend for the last N days grouped by service, region, usage_type or account.",
                  "inputSchema": {"json": {"type": "object", "properties": {
                      "days": {"type": "integer"},
                      "group_by": {"type": "string",
                                   "enum": ["service", "region", "usage_type", "account"]}}}}}},
    {"toolSpec": {"name": "find_idle_resources",
                  "description": "Find unattached EBS, unused Elastic IPs, stopped and low-CPU instances.",
                  "inputSchema": {"json": {"type": "object", "properties": _REGION}}}},
    {"toolSpec": {"name": "get_rightsizing_recommendations",
                  "description": "EC2 rightsizing recommendations with estimated savings (Compute Optimizer).",
                  "inputSchema": {"json": {"type": "object", "properties": _REGION}}}},
    {"toolSpec": {"name": "check_request_status",
                  "description": "Check progress of a provisioning or deletion request by its request ID.",
                  "inputSchema": {"json": {"type": "object",
                                           "properties": {"request_id": {"type": "string"}},
                                           "required": ["request_id"]}}}},
    # ---- change tools (create pending actions only)
    {"toolSpec": {"name": "request_provision",
                  "description": "Propose provisioning an EC2 instance or S3 bucket. Requires user confirmation.",
                  "inputSchema": {"json": {"type": "object", "properties": {
                      "resource_type": {"type": "string", "enum": ["ec2", "s3"]},
                      "name": {"type": "string", "description": "Resource name / Name tag"},
                      "environment": {"type": "string", "enum": ["dev", "staging", "prod"]},
                      "region": {"type": "string"},
                      "instance_type": {"type": "string", "description": "EC2 only, e.g. t3.micro"},
                      "owner_team": {"type": "string"},
                      "notes": {"type": "string"}},
                      "required": ["resource_type", "name", "environment"]}}}},
    {"toolSpec": {"name": "request_delete",
                  "description": "Propose deleting resources created by a previous provisioning ticket. Requires user confirmation.",
                  "inputSchema": {"json": {"type": "object", "properties": {
                      "ticket_id": {"type": "string", "description": "Original provisioning ticket / request ID"},
                      "reason": {"type": "string"}},
                      "required": ["ticket_id", "reason"]}}}},
]


# ================================================================ helpers

def _resp(code, body):
    return {"statusCode": code,
            "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"},
            "body": json.dumps(body, default=str)}


def _caller(event):
    """User identity + groups from an API Gateway JWT/Cognito authorizer."""
    auth = event.get("requestContext", {}).get("authorizer", {}) or {}
    claims = auth.get("jwt", {}).get("claims") or auth.get("claims") or {}
    groups = claims.get("cognito:groups", [])
    if isinstance(groups, str):  # HTTP APIs pass groups as "[a b]"
        groups = groups.strip("[]").replace(",", " ").split()
    return claims.get("email") or claims.get("sub") or "anonymous", set(groups)


def load_history(session_id):
    item = sessions.get_item(Key={"session_id": session_id}).get("Item")
    return json.loads(item["history"]) if item else []


def save_history(session_id, history):
    sessions.put_item(Item={
        "session_id": session_id,
        "history": json.dumps(history[-HISTORY_TURNS * 2:]),
        "expires_at": int(time.time()) + SESSION_TTL_SECONDS,
    })


def append_turn(session_id, user_text, assistant_text):
    history = load_history(session_id)
    save_history(session_id, history + [
        {"role": "user", "content": [{"text": user_text}]},
        {"role": "assistant", "content": [{"text": assistant_text}]},
    ])


# ================================================================ Step Function bridge

def build_sfn_input(kind, params, request_id, user):
    """
    >>> ADAPT THIS to match the body your chat UI sends to the Step Function today,
    so ChatOps-Input-Parser accepts it unchanged. The method fields satisfy your
    'Route by Method' Choice state (both HTTP API and REST API shapes).
    """
    common = {"request_id": request_id, "requested_by": user, "source": "ai-agent"}
    if kind == "provision":
        body = {**params, **common}
    else:  # delete -> routed by 'Is Deletion Request?' via original_provision_ticket_id
        body = {"original_provision_ticket_id": params["ticket_id"],
                "reason": params.get("reason"), **common}
    return {"httpMethod": "POST",
            "requestContext": {"http": {"method": "POST"}},
            "body": json.dumps(body)}


def _execution_arn(request_id):
    return STATE_MACHINE_ARN.replace(":stateMachine:", ":execution:") + ":" + request_id


def get_request_status(request_id):
    out = {"request_id": request_id}
    try:
        ex = sfn.describe_execution(executionArn=_execution_arn(request_id))
        status = ex["status"]
        out["workflow_status"] = status
        out["state"] = {"RUNNING": "in_progress", "SUCCEEDED": "done"}.get(status, "failed")
        if status == "SUCCEEDED" and ex.get("output"):
            o = json.loads(ex["output"])
            out["result"] = o.get("provisioningResult") or o.get("deleteExecutionResult")
        elif status != "RUNNING":
            out["error"] = ex.get("error")
            out["cause"] = (ex.get("cause") or "")[:1000]
    except sfn.exceptions.ExecutionDoesNotExist:
        out["workflow_status"], out["state"] = "NOT_FOUND", "failed"

    # Same lookup your GET status route does
    try:
        items = resources.query(IndexName="request_id-index",
                                KeyConditionExpression=Key("request_id").eq(request_id))["Items"]
        out["resources"] = items[:20]
    except ClientError as e:
        out["resources_lookup_error"] = e.response["Error"]["Code"]
    return out


# ================================================================ pending actions

def describe_action(kind, p):
    if kind == "provision":
        extra = f", {p['instance_type']}" if p.get("instance_type") else ""
        return (f"Provision {p['resource_type'].upper()} '{p['name']}' in "
                f"{p.get('region') or DEFAULT_REGION} ({p['environment']}{extra})")
    return f"Delete resources from ticket {p['ticket_id']} (reason: {p.get('reason', '-')})"


def create_pending_action(ctx, kind, params):
    if kind == "delete" and ADMIN_GROUP and ADMIN_GROUP not in ctx["groups"]:
        return {"error": f"Only members of '{ADMIN_GROUP}' can request deletions. "
                         "Ask an admin to run this."}
    if kind == "provision":
        params.setdefault("region", DEFAULT_REGION)
        if params["resource_type"] == "ec2" and not params.get("instance_type"):
            return {"error": "instance_type is required for EC2. Ask the user."}

    action_id = f"req-{uuid.uuid4().hex[:12]}"
    summary = describe_action(kind, params)
    sessions.put_item(Item={
        "session_id": f"action#{action_id}",
        "kind": kind,
        "params": json.dumps(params),
        "summary": summary,
        "owner_session": ctx["session_id"],
        "user": ctx["user"],
        "status": "PENDING",
        "expires_at": int(time.time()) + ACTION_TTL_SECONDS,
    })
    ctx["pending_actions"].append({"action_id": action_id, "kind": kind, "summary": summary,
                                   "params": params, "expires_in": ACTION_TTL_SECONDS})
    return {"status": "AWAITING_USER_CONFIRMATION", "action_id": action_id, "summary": summary}


def handle_decision(body, session_id, user):
    action_id = body.get("action_id", "")
    approve = body.get("decision") == "confirm"
    key = {"session_id": f"action#{action_id}"}
    item = sessions.get_item(Key=key).get("Item")

    if not item or item["owner_session"] != session_id or item["user"] != user:
        return _resp(404, {"error": "Action not found", "session_id": session_id})
    if item["expires_at"] < time.time():
        return _resp(410, {"error": "This request expired. Ask me again.", "session_id": session_id})

    # Atomically claim the action so a double-click can't run it twice
    try:
        sessions.update_item(
            Key=key,
            UpdateExpression="SET #s = :new",
            ConditionExpression="#s = :pending",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":new": "APPROVED" if approve else "CANCELLED",
                                       ":pending": "PENDING"})
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return _resp(409, {"error": "Already handled", "session_id": session_id})
        raise

    summary = item["summary"]
    if not approve:
        reply = f"Cancelled: {summary}. Nothing was changed."
        append_turn(session_id, f"[User cancelled: {summary}]", reply)
        return _resp(200, {"reply": reply, "session_id": session_id})

    try:
        sfn.start_execution(
            stateMachineArn=STATE_MACHINE_ARN,
            name=action_id,  # execution name = request ID, used for status lookups
            input=json.dumps(build_sfn_input(item["kind"], json.loads(item["params"]),
                                             action_id, user)))
    except ClientError as e:
        sessions.update_item(Key=key, UpdateExpression="SET #s = :f",
                             ExpressionAttributeNames={"#s": "status"},
                             ExpressionAttributeValues={":f": "FAILED_TO_START"})
        print(f"start_execution failed: {e}")
        return _resp(502, {"error": "Could not start the workflow", "session_id": session_id})

    print(f"AUDIT user={user} approved {action_id}: {summary}")
    reply = f"Submitted: {summary}\nRequest ID `{action_id}`. I'll show progress here."
    append_turn(session_id, f"[User confirmed: {summary}]", reply)
    return _resp(200, {"reply": reply, "session_id": session_id,
                       "tracking": {"request_id": action_id, "state": "in_progress"}})


# ================================================================ agent loop

def run_tool(name, args, ctx):
    region = args.get("region") or DEFAULT_REGION
    if name == "list_running_resources":
        return list_running_resources(region)
    if name == "get_cost_breakdown":
        return get_cost_breakdown(int(args.get("days", 30)), args.get("group_by", "service"))
    if name == "find_idle_resources":
        return find_idle_resources(region)
    if name == "get_rightsizing_recommendations":
        return get_rightsizing_recommendations(region)
    if name == "check_request_status":
        return get_request_status(args["request_id"])
    if name == "request_provision":
        return create_pending_action(ctx, "provision", dict(args))
    if name == "request_delete":
        return create_pending_action(ctx, "delete", dict(args))
    return {"error": f"Unknown tool {name}"}


def run_agent(history, question, ctx, lambda_context):
    messages = history + [{"role": "user", "content": [{"text": question}]}]

    for _ in range(MAX_TOOL_ROUNDS):
        if lambda_context.get_remaining_time_in_millis() < MIN_TIME_LEFT_MS:
            return "That needs more work than I can finish in one request. Try narrowing it."

        resp = bedrock.converse(
            modelId=MODEL_ID,
            system=[{"text": SYSTEM_PROMPT}],
            messages=messages,
            toolConfig={"tools": TOOL_SPECS},
            inferenceConfig={"maxTokens": 4096},
        )
        msg = resp["output"]["message"]
        messages.append(msg)
        if resp["stopReason"] != "tool_use":
            return "".join(b.get("text", "") for b in msg["content"]).strip()

        results = []
        for block in msg["content"]:
            if "toolUse" not in block:
                continue
            call = block["toolUse"]
            print(f"tool call: {call['name']} {call.get('input')}")
            try:
                result = run_tool(call["name"], call.get("input") or {}, ctx)
            except Exception as e:
                result = {"error": f"{type(e).__name__}: {e}"}
            text = json.dumps(result, default=str)[:MAX_TOOL_RESULT_CHARS]
            results.append({"toolResult": {"toolUseId": call["toolUseId"],
                                           "content": [{"text": text}]}})
        messages.append({"role": "user", "content": results})

    return "I hit my tool-call limit. Try asking something more specific."


# ================================================================ handler

def lambda_handler(event, context):
    raw = event.get("body") or "{}"
    if event.get("isBase64Encoded"):
        raw = base64.b64decode(raw).decode()
    try:
        body = json.loads(raw)
    except json.JSONDecodeError:
        return _resp(400, {"error": "Body must be JSON"})

    session_id = body.get("session_id") or str(uuid.uuid4())
    user, groups = _caller(event)

    try:
        if body.get("action_id") and body.get("decision"):
            return handle_decision(body, session_id, user)

        if body.get("status_request_id"):
            status = get_request_status(body["status_request_id"])
            return _resp(200, {"session_id": session_id, "tracking": status})

        question = (body.get("message") or "").strip()
        if not question:
            return _resp(400, {"error": "'message' is required", "session_id": session_id})

        ctx = {"session_id": session_id, "user": user, "groups": groups, "pending_actions": []}
        history = load_history(session_id)
        reply = run_agent(history, question, ctx, context)
        save_history(session_id, history + [
            {"role": "user", "content": [{"text": question}]},
            {"role": "assistant", "content": [{"text": reply}]},
        ])
        return _resp(200, {"reply": reply, "session_id": session_id,
                           "actions": ctx["pending_actions"]})
    except Exception as e:
        print(f"agent failed: {type(e).__name__}: {e}")
        return _resp(502, {"error": "Agent failed to respond", "session_id": session_id})
